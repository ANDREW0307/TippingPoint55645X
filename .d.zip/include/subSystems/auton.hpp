#include "main.h"


void left_side();
void right_side();

void skills_260();
void skills_290();

void testingAuton();
